package com.capgemini.bank.bean;
import java.util.Date;
public class DemandDraft {
	private int transactionId;
	private String customerName;
	private String inFavorOf;
	private String phoneNumber;
	private String dateOfTransaction;
	private int ddAmount;
	private int ddCommission;
	private String ddDescription;
	public DemandDraft() {
		super();
	}
	public DemandDraft(int transactionId, String customerName,
			String inFavorOf, String phoneNumber, String dateOfTransaction,
			int ddAmount, int ddCommission, String ddDescription) {
		super();
		this.transactionId = transactionId;
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.phoneNumber = phoneNumber;
		this.dateOfTransaction = dateOfTransaction;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.ddDescription = ddDescription;
	}
	public DemandDraft(String customerName, String inFavorOf,
			String phoneNumber,int ddAmount,
			int ddCommission, String ddDescription) {
		super();
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.phoneNumber = phoneNumber;
		this.dateOfTransaction = dateOfTransaction;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.ddDescription = ddDescription;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInFavorOf() {
		return inFavorOf;
	}
	public void setInFavorOf(String inFavorOf) {
		this.inFavorOf = inFavorOf;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(String dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public int getDdAmount() {
		return ddAmount;
	}
	public void setDdAmount(int ddAmount) {
		this.ddAmount = ddAmount;
	}
	public int getDdCommission() {
		return ddCommission;
	}
	public void setDdCommission(int ddCommission) {
		this.ddCommission = ddCommission;
	}
	public String getDdDescription() {
		return ddDescription;
	}
	public void setDdDescription(String ddDescription) {
		this.ddDescription = ddDescription;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((customerName == null) ? 0 : customerName.hashCode());
		result = prime
				* result
				+ ((dateOfTransaction == null) ? 0 : dateOfTransaction
						.hashCode());
		result = prime * result + ddAmount;
		result = prime * result + ddCommission;
		result = prime * result
				+ ((ddDescription == null) ? 0 : ddDescription.hashCode());
		result = prime * result
				+ ((inFavorOf == null) ? 0 : inFavorOf.hashCode());
		result = prime * result
				+ ((phoneNumber == null) ? 0 : phoneNumber.hashCode());
		result = prime * result + transactionId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DemandDraft other = (DemandDraft) obj;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (dateOfTransaction == null) {
			if (other.dateOfTransaction != null)
				return false;
		} else if (!dateOfTransaction.equals(other.dateOfTransaction))
			return false;
		if (ddAmount != other.ddAmount)
			return false;
		if (ddCommission != other.ddCommission)
			return false;
		if (ddDescription == null) {
			if (other.ddDescription != null)
				return false;
		} else if (!ddDescription.equals(other.ddDescription))
			return false;
		if (inFavorOf == null) {
			if (other.inFavorOf != null)
				return false;
		} else if (!inFavorOf.equals(other.inFavorOf))
			return false;
		if (phoneNumber == null) {
			if (other.phoneNumber != null)
				return false;
		} else if (!phoneNumber.equals(other.phoneNumber))
			return false;
		if (transactionId != other.transactionId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "DemandDraft [transactionId=" + transactionId
				+ ", customerName=" + customerName + ", inFavorOf=" + inFavorOf
				+ ", phoneNumber=" + phoneNumber + ", dateOfTransaction="
				+ dateOfTransaction + ", ddAmount=" + ddAmount
				+ ", ddCommission=" + ddCommission + ", ddDescription="
				+ ddDescription + "]";
	}
}
