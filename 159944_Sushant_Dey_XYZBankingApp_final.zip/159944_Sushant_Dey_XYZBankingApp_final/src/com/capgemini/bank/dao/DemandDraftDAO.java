package com.capgemini.bank.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.util.ConnectionProvider;
public class DemandDraftDAO implements IDemandDraftDAO{
	private static final Logger logger = Logger.getLogger(DemandDraftService.class);
	private Connection conn = ConnectionProvider.getDBConnection();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException {
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("insert into demand_draft (transaction_Id, customer_name, in_favor_of, phone_number, date_of_transaction, dd_amount, dd_commission, dd_description) values (Transaction_Id_Seq.nextVal, ?, ?, ?,  sysdate, ?, ?, ?)");
			pstmt1.setString(1, demandDraft.getCustomerName());
			pstmt1.setString(2, demandDraft.getInFavorOf());
			pstmt1.setString(3, demandDraft.getPhoneNumber());
			pstmt1.setInt(4, demandDraft.getDdAmount());
			pstmt1.setInt(5, demandDraft.getDdCommission());
			pstmt1.setString(6, demandDraft.getDdDescription());
			pstmt1.executeUpdate();
			conn.commit();

			PreparedStatement pstmt2 = conn.prepareStatement("select max(transaction_Id) from demand_draft");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int transactionId = rs.getInt(1);
			return transactionId;
		}catch (SQLException e){
			/*e.printStackTrace();*/
			conn.rollback();
			logger.error(e.getMessage()+" "+e.getCause()+" "+e.getErrorCode());
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws SQLException {
		try{
		PreparedStatement pstmt1 = conn.prepareStatement("Select * from demand_draft where transaction_Id="+transactionId);
		ResultSet demandDraftRS = pstmt1.executeQuery();
		if(demandDraftRS.next()) {
			String customerName = demandDraftRS.getString("customer_name");
			String inFavorOf = demandDraftRS.getString("in_favor_of");
			String phoneNumber = demandDraftRS.getString("phone_number");
			String dateOfTransaction = demandDraftRS.getString("date_of_transaction");
			int ddAmount = demandDraftRS.getInt("dd_amount");
			int ddCommission = demandDraftRS.getInt("dd_commission");
			String ddDescription = demandDraftRS.getString("dd_description");
			DemandDraft demandDraft = new DemandDraft(transactionId, customerName, inFavorOf, phoneNumber, dateOfTransaction, ddAmount, ddCommission, ddDescription);
			return demandDraft;
		}
		}catch (SQLException e){
			/*e.printStackTrace();*/
			conn.rollback();
			logger.error(e.getMessage()+" "+e.getCause()+" "+e.getErrorCode());
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
		return null;
	}
}
