package com.capgemini.bank.test;
import static org.junit.Assert.*;

import java.util.InputMismatchException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.InvalidInputException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
public class DemandDraftServiceTest {
	static IDemandDraftService demandDraft;
	@BeforeClass
	public static void setUPTestEnv(){
		demandDraft = new DemandDraftService();
	}
	@Before
	public void setUpMockDataForTest(){
	}
	@Test(expected=InvalidInputException.class)
	public void testInvalidDDAmount() throws InvalidInputException{
		
	}
	@After
	public void tearDownMockDataForTest(){
		System.out.println("tearDownMockDataForTest()");
	}
	@AfterClass
	public static void tearDownSetUPTestEnv(){
		demandDraft=null;
	}
}
