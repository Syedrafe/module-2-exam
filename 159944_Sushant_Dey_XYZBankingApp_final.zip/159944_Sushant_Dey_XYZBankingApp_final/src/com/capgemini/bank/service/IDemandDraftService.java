package com.capgemini.bank.service;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftServicesDownException;
public interface IDemandDraftService {
	public DemandDraft getDemandDraftDetails(int transactionId) throws DemandDraftServicesDownException;
	public int addDemandDraftDetails(String customerName, String phoneNumber,
			String inFavorOf, int ddAmount, String ddDescription) throws DemandDraftServicesDownException;
}
